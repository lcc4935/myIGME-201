﻿namespace Casale_UnitTest3_President
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.bHRadioButton = new System.Windows.Forms.RadioButton();
            this.fDRRadioButton = new System.Windows.Forms.RadioButton();
            this.wJCRadioButton = new System.Windows.Forms.RadioButton();
            this.jBRadioButton = new System.Windows.Forms.RadioButton();
            this.fPRadioButton = new System.Windows.Forms.RadioButton();
            this.gWBRadioButton = new System.Windows.Forms.RadioButton();
            this.bORadioButton = new System.Windows.Forms.RadioButton();
            this.jFKRadioButton = new System.Windows.Forms.RadioButton();
            this.bHTextBox = new System.Windows.Forms.TextBox();
            this.fDRTextBox = new System.Windows.Forms.TextBox();
            this.wJCTextBox = new System.Windows.Forms.TextBox();
            this.jBTextBox = new System.Windows.Forms.TextBox();
            this.fPTextBox = new System.Windows.Forms.TextBox();
            this.gWBTextBox = new System.Windows.Forms.TextBox();
            this.bOTextBox = new System.Windows.Forms.TextBox();
            this.jFKTextBox = new System.Windows.Forms.TextBox();
            this.tJTextBox = new System.Windows.Forms.TextBox();
            this.tRTextBox = new System.Windows.Forms.TextBox();
            this.jATextBox = new System.Windows.Forms.TextBox();
            this.gWTextBox = new System.Windows.Forms.TextBox();
            this.mVTextBox = new System.Windows.Forms.TextBox();
            this.dDETextBox = new System.Windows.Forms.TextBox();
            this.rRTextBox = new System.Windows.Forms.TextBox();
            this.wMTextBox = new System.Windows.Forms.TextBox();
            this.tJRadioButton = new System.Windows.Forms.RadioButton();
            this.tRRadioButton = new System.Windows.Forms.RadioButton();
            this.jARadioButton = new System.Windows.Forms.RadioButton();
            this.gWRadioButton = new System.Windows.Forms.RadioButton();
            this.mVRadioButton = new System.Windows.Forms.RadioButton();
            this.dDERadioButton = new System.Windows.Forms.RadioButton();
            this.rRRadioButton = new System.Windows.Forms.RadioButton();
            this.wMRadioButton = new System.Windows.Forms.RadioButton();
            this.filterGroupBox = new System.Windows.Forms.GroupBox();
            this.fedRadioButton = new System.Windows.Forms.RadioButton();
            this.dRRadioButton = new System.Windows.Forms.RadioButton();
            this.repRadioButton = new System.Windows.Forms.RadioButton();
            this.demRadioButton = new System.Windows.Forms.RadioButton();
            this.allRadioButton = new System.Windows.Forms.RadioButton();
            this.pictureBox = new System.Windows.Forms.PictureBox();
            this.groupBox = new System.Windows.Forms.GroupBox();
            this.webBrowser = new System.Windows.Forms.WebBrowser();
            this.exitButton = new System.Windows.Forms.Button();
            this.statusStrip = new System.Windows.Forms.StatusStrip();
            this.progressBar = new System.Windows.Forms.ProgressBar();
            this.timer = new System.Windows.Forms.Timer(this.components);
            this.errorProvider = new System.Windows.Forms.ErrorProvider(this.components);
            this.toolTip = new System.Windows.Forms.ToolTip(this.components);
            this.filterGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).BeginInit();
            this.groupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).BeginInit();
            this.SuspendLayout();
            // 
            // bHRadioButton
            // 
            this.bHRadioButton.AutoSize = true;
            this.bHRadioButton.Checked = true;
            this.bHRadioButton.Location = new System.Drawing.Point(13, 13);
            this.bHRadioButton.Name = "bHRadioButton";
            this.bHRadioButton.Size = new System.Drawing.Size(110, 17);
            this.bHRadioButton.TabIndex = 0;
            this.bHRadioButton.TabStop = true;
            this.bHRadioButton.Text = "Benjamin Harrison";
            this.bHRadioButton.UseVisualStyleBackColor = true;
            // 
            // fDRRadioButton
            // 
            this.fDRRadioButton.AutoSize = true;
            this.fDRRadioButton.Location = new System.Drawing.Point(13, 45);
            this.fDRRadioButton.Name = "fDRRadioButton";
            this.fDRRadioButton.Size = new System.Drawing.Size(124, 17);
            this.fDRRadioButton.TabIndex = 1;
            this.fDRRadioButton.Text = "Franklin D Roosevelt";
            this.fDRRadioButton.UseVisualStyleBackColor = true;
            // 
            // wJCRadioButton
            // 
            this.wJCRadioButton.AutoSize = true;
            this.wJCRadioButton.Location = new System.Drawing.Point(13, 79);
            this.wJCRadioButton.Name = "wJCRadioButton";
            this.wJCRadioButton.Size = new System.Drawing.Size(101, 17);
            this.wJCRadioButton.TabIndex = 2;
            this.wJCRadioButton.Text = "William J Clinton";
            this.wJCRadioButton.UseVisualStyleBackColor = true;
            // 
            // jBRadioButton
            // 
            this.jBRadioButton.AutoSize = true;
            this.jBRadioButton.Location = new System.Drawing.Point(13, 112);
            this.jBRadioButton.Name = "jBRadioButton";
            this.jBRadioButton.Size = new System.Drawing.Size(107, 17);
            this.jBRadioButton.TabIndex = 3;
            this.jBRadioButton.Text = "James Buchanan";
            this.jBRadioButton.UseVisualStyleBackColor = true;
            // 
            // fPRadioButton
            // 
            this.fPRadioButton.AutoSize = true;
            this.fPRadioButton.Location = new System.Drawing.Point(13, 146);
            this.fPRadioButton.Name = "fPRadioButton";
            this.fPRadioButton.Size = new System.Drawing.Size(95, 17);
            this.fPRadioButton.TabIndex = 4;
            this.fPRadioButton.Text = "Franklin Pierce";
            this.fPRadioButton.UseVisualStyleBackColor = true;
            // 
            // gWBRadioButton
            // 
            this.gWBRadioButton.AutoSize = true;
            this.gWBRadioButton.Location = new System.Drawing.Point(13, 179);
            this.gWBRadioButton.Name = "gWBRadioButton";
            this.gWBRadioButton.Size = new System.Drawing.Size(101, 17);
            this.gWBRadioButton.TabIndex = 5;
            this.gWBRadioButton.Text = "George W Bush";
            this.gWBRadioButton.UseVisualStyleBackColor = true;
            // 
            // bORadioButton
            // 
            this.bORadioButton.AutoSize = true;
            this.bORadioButton.Location = new System.Drawing.Point(13, 213);
            this.bORadioButton.Name = "bORadioButton";
            this.bORadioButton.Size = new System.Drawing.Size(90, 17);
            this.bORadioButton.TabIndex = 6;
            this.bORadioButton.Text = "Barak Obama";
            this.bORadioButton.UseVisualStyleBackColor = true;
            // 
            // jFKRadioButton
            // 
            this.jFKRadioButton.AutoSize = true;
            this.jFKRadioButton.Location = new System.Drawing.Point(13, 247);
            this.jFKRadioButton.Name = "jFKRadioButton";
            this.jFKRadioButton.Size = new System.Drawing.Size(102, 17);
            this.jFKRadioButton.TabIndex = 7;
            this.jFKRadioButton.Text = "John F Kennedy";
            this.jFKRadioButton.UseVisualStyleBackColor = true;
            // 
            // bHTextBox
            // 
            this.bHTextBox.AccessibleDescription = "";
            this.bHTextBox.AccessibleName = "";
            this.bHTextBox.Location = new System.Drawing.Point(142, 12);
            this.bHTextBox.Name = "bHTextBox";
            this.bHTextBox.Size = new System.Drawing.Size(36, 20);
            this.bHTextBox.TabIndex = 16;
            this.bHTextBox.Text = "0";
            // 
            // fDRTextBox
            // 
            this.fDRTextBox.Location = new System.Drawing.Point(142, 44);
            this.fDRTextBox.Name = "fDRTextBox";
            this.fDRTextBox.Size = new System.Drawing.Size(36, 20);
            this.fDRTextBox.TabIndex = 17;
            this.fDRTextBox.Text = "0";
            // 
            // wJCTextBox
            // 
            this.wJCTextBox.Location = new System.Drawing.Point(142, 78);
            this.wJCTextBox.Name = "wJCTextBox";
            this.wJCTextBox.Size = new System.Drawing.Size(36, 20);
            this.wJCTextBox.TabIndex = 18;
            this.wJCTextBox.Text = "0";
            // 
            // jBTextBox
            // 
            this.jBTextBox.Location = new System.Drawing.Point(142, 111);
            this.jBTextBox.Name = "jBTextBox";
            this.jBTextBox.Size = new System.Drawing.Size(36, 20);
            this.jBTextBox.TabIndex = 19;
            this.jBTextBox.Text = "0";
            // 
            // fPTextBox
            // 
            this.fPTextBox.Location = new System.Drawing.Point(142, 145);
            this.fPTextBox.Name = "fPTextBox";
            this.fPTextBox.Size = new System.Drawing.Size(36, 20);
            this.fPTextBox.TabIndex = 20;
            this.fPTextBox.Text = "0";
            // 
            // gWBTextBox
            // 
            this.gWBTextBox.Location = new System.Drawing.Point(142, 178);
            this.gWBTextBox.Name = "gWBTextBox";
            this.gWBTextBox.Size = new System.Drawing.Size(36, 20);
            this.gWBTextBox.TabIndex = 21;
            this.gWBTextBox.Text = "0";
            // 
            // bOTextBox
            // 
            this.bOTextBox.Location = new System.Drawing.Point(142, 212);
            this.bOTextBox.Name = "bOTextBox";
            this.bOTextBox.Size = new System.Drawing.Size(36, 20);
            this.bOTextBox.TabIndex = 22;
            this.bOTextBox.Text = "0";
            // 
            // jFKTextBox
            // 
            this.jFKTextBox.Location = new System.Drawing.Point(142, 246);
            this.jFKTextBox.Name = "jFKTextBox";
            this.jFKTextBox.Size = new System.Drawing.Size(36, 20);
            this.jFKTextBox.TabIndex = 23;
            this.jFKTextBox.Text = "0";
            // 
            // tJTextBox
            // 
            this.tJTextBox.Location = new System.Drawing.Point(354, 246);
            this.tJTextBox.Name = "tJTextBox";
            this.tJTextBox.Size = new System.Drawing.Size(36, 20);
            this.tJTextBox.TabIndex = 39;
            this.tJTextBox.Text = "0";
            // 
            // tRTextBox
            // 
            this.tRTextBox.Location = new System.Drawing.Point(354, 212);
            this.tRTextBox.Name = "tRTextBox";
            this.tRTextBox.Size = new System.Drawing.Size(36, 20);
            this.tRTextBox.TabIndex = 38;
            this.tRTextBox.Text = "0";
            // 
            // jATextBox
            // 
            this.jATextBox.Location = new System.Drawing.Point(354, 178);
            this.jATextBox.Name = "jATextBox";
            this.jATextBox.Size = new System.Drawing.Size(36, 20);
            this.jATextBox.TabIndex = 37;
            this.jATextBox.Text = "0";
            // 
            // gWTextBox
            // 
            this.gWTextBox.Location = new System.Drawing.Point(354, 145);
            this.gWTextBox.Name = "gWTextBox";
            this.gWTextBox.Size = new System.Drawing.Size(36, 20);
            this.gWTextBox.TabIndex = 36;
            this.gWTextBox.Text = "0";
            // 
            // mVTextBox
            // 
            this.mVTextBox.Location = new System.Drawing.Point(354, 111);
            this.mVTextBox.Name = "mVTextBox";
            this.mVTextBox.Size = new System.Drawing.Size(36, 20);
            this.mVTextBox.TabIndex = 35;
            this.mVTextBox.Text = "0";
            // 
            // dDETextBox
            // 
            this.dDETextBox.Location = new System.Drawing.Point(354, 78);
            this.dDETextBox.Name = "dDETextBox";
            this.dDETextBox.Size = new System.Drawing.Size(36, 20);
            this.dDETextBox.TabIndex = 34;
            this.dDETextBox.Text = "0";
            // 
            // rRTextBox
            // 
            this.rRTextBox.Location = new System.Drawing.Point(354, 44);
            this.rRTextBox.Name = "rRTextBox";
            this.rRTextBox.Size = new System.Drawing.Size(36, 20);
            this.rRTextBox.TabIndex = 33;
            this.rRTextBox.Text = "0";
            // 
            // wMTextBox
            // 
            this.wMTextBox.Location = new System.Drawing.Point(354, 12);
            this.wMTextBox.Name = "wMTextBox";
            this.wMTextBox.Size = new System.Drawing.Size(36, 20);
            this.wMTextBox.TabIndex = 32;
            this.wMTextBox.Text = "0";
            // 
            // tJRadioButton
            // 
            this.tJRadioButton.AutoSize = true;
            this.tJRadioButton.Location = new System.Drawing.Point(225, 247);
            this.tJRadioButton.Name = "tJRadioButton";
            this.tJRadioButton.Size = new System.Drawing.Size(109, 17);
            this.tJRadioButton.TabIndex = 31;
            this.tJRadioButton.Text = "Thomas Jefferson";
            this.tJRadioButton.UseVisualStyleBackColor = true;
            // 
            // tRRadioButton
            // 
            this.tRRadioButton.AutoSize = true;
            this.tRRadioButton.Location = new System.Drawing.Point(225, 213);
            this.tRRadioButton.Name = "tRRadioButton";
            this.tRRadioButton.Size = new System.Drawing.Size(122, 17);
            this.tRRadioButton.TabIndex = 30;
            this.tRRadioButton.Text = "Theodore Roosevelt";
            this.tRRadioButton.UseVisualStyleBackColor = true;
            // 
            // jARadioButton
            // 
            this.jARadioButton.AutoSize = true;
            this.jARadioButton.Location = new System.Drawing.Point(225, 179);
            this.jARadioButton.Name = "jARadioButton";
            this.jARadioButton.Size = new System.Drawing.Size(83, 17);
            this.jARadioButton.TabIndex = 29;
            this.jARadioButton.Text = "John Adams";
            this.jARadioButton.UseVisualStyleBackColor = true;
            // 
            // gWRadioButton
            // 
            this.gWRadioButton.AutoSize = true;
            this.gWRadioButton.Location = new System.Drawing.Point(225, 146);
            this.gWRadioButton.Name = "gWRadioButton";
            this.gWRadioButton.Size = new System.Drawing.Size(120, 17);
            this.gWRadioButton.TabIndex = 28;
            this.gWRadioButton.Text = "George Washington";
            this.gWRadioButton.UseVisualStyleBackColor = true;
            // 
            // mVRadioButton
            // 
            this.mVRadioButton.AutoSize = true;
            this.mVRadioButton.Location = new System.Drawing.Point(225, 112);
            this.mVRadioButton.Name = "mVRadioButton";
            this.mVRadioButton.Size = new System.Drawing.Size(104, 17);
            this.mVRadioButton.TabIndex = 27;
            this.mVRadioButton.Text = "Martin VanBuren";
            this.mVRadioButton.UseVisualStyleBackColor = true;
            // 
            // dDERadioButton
            // 
            this.dDERadioButton.AutoSize = true;
            this.dDERadioButton.Location = new System.Drawing.Point(225, 79);
            this.dDERadioButton.Name = "dDERadioButton";
            this.dDERadioButton.Size = new System.Drawing.Size(127, 17);
            this.dDERadioButton.TabIndex = 26;
            this.dDERadioButton.Text = "Dwight D Eisenhower";
            this.dDERadioButton.UseVisualStyleBackColor = true;
            // 
            // rRRadioButton
            // 
            this.rRRadioButton.AutoSize = true;
            this.rRRadioButton.Location = new System.Drawing.Point(225, 45);
            this.rRRadioButton.Name = "rRRadioButton";
            this.rRRadioButton.Size = new System.Drawing.Size(100, 17);
            this.rRRadioButton.TabIndex = 25;
            this.rRRadioButton.Text = "Ronald Reagan";
            this.rRRadioButton.UseVisualStyleBackColor = true;
            // 
            // wMRadioButton
            // 
            this.wMRadioButton.AutoSize = true;
            this.wMRadioButton.Location = new System.Drawing.Point(225, 13);
            this.wMRadioButton.Name = "wMRadioButton";
            this.wMRadioButton.Size = new System.Drawing.Size(104, 17);
            this.wMRadioButton.TabIndex = 24;
            this.wMRadioButton.Text = "William McKinley";
            this.wMRadioButton.UseVisualStyleBackColor = true;
            // 
            // filterGroupBox
            // 
            this.filterGroupBox.Controls.Add(this.fedRadioButton);
            this.filterGroupBox.Controls.Add(this.dRRadioButton);
            this.filterGroupBox.Controls.Add(this.repRadioButton);
            this.filterGroupBox.Controls.Add(this.demRadioButton);
            this.filterGroupBox.Controls.Add(this.allRadioButton);
            this.filterGroupBox.Location = new System.Drawing.Point(225, 319);
            this.filterGroupBox.Name = "filterGroupBox";
            this.filterGroupBox.Size = new System.Drawing.Size(165, 149);
            this.filterGroupBox.TabIndex = 41;
            this.filterGroupBox.TabStop = false;
            this.filterGroupBox.Text = "Filter";
            // 
            // fedRadioButton
            // 
            this.fedRadioButton.AutoSize = true;
            this.fedRadioButton.Location = new System.Drawing.Point(6, 112);
            this.fedRadioButton.Name = "fedRadioButton";
            this.fedRadioButton.Size = new System.Drawing.Size(70, 17);
            this.fedRadioButton.TabIndex = 4;
            this.fedRadioButton.Text = "Federalist";
            this.fedRadioButton.UseVisualStyleBackColor = true;
            // 
            // dRRadioButton
            // 
            this.dRRadioButton.AutoSize = true;
            this.dRRadioButton.Location = new System.Drawing.Point(6, 89);
            this.dRRadioButton.Name = "dRRadioButton";
            this.dRRadioButton.Size = new System.Drawing.Size(136, 17);
            this.dRRadioButton.TabIndex = 3;
            this.dRRadioButton.Text = "Democratic-Republican";
            this.dRRadioButton.UseVisualStyleBackColor = true;
            // 
            // repRadioButton
            // 
            this.repRadioButton.AutoSize = true;
            this.repRadioButton.Location = new System.Drawing.Point(7, 66);
            this.repRadioButton.Name = "repRadioButton";
            this.repRadioButton.Size = new System.Drawing.Size(79, 17);
            this.repRadioButton.TabIndex = 2;
            this.repRadioButton.Text = "Republican";
            this.repRadioButton.UseVisualStyleBackColor = true;
            // 
            // demRadioButton
            // 
            this.demRadioButton.AutoSize = true;
            this.demRadioButton.Location = new System.Drawing.Point(7, 43);
            this.demRadioButton.Name = "demRadioButton";
            this.demRadioButton.Size = new System.Drawing.Size(71, 17);
            this.demRadioButton.TabIndex = 1;
            this.demRadioButton.Text = "Democrat";
            this.demRadioButton.UseVisualStyleBackColor = true;
            // 
            // allRadioButton
            // 
            this.allRadioButton.AutoSize = true;
            this.allRadioButton.Checked = true;
            this.allRadioButton.Location = new System.Drawing.Point(7, 20);
            this.allRadioButton.Name = "allRadioButton";
            this.allRadioButton.Size = new System.Drawing.Size(36, 17);
            this.allRadioButton.TabIndex = 0;
            this.allRadioButton.TabStop = true;
            this.allRadioButton.Text = "All";
            this.allRadioButton.UseVisualStyleBackColor = true;
            // 
            // pictureBox
            // 
            this.pictureBox.ImageLocation = "https://people.rit.edu/dxsigm/BenjaminHarrison.jpeg";
            this.pictureBox.Location = new System.Drawing.Point(12, 319);
            this.pictureBox.Name = "pictureBox";
            this.pictureBox.Size = new System.Drawing.Size(150, 200);
            this.pictureBox.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox.TabIndex = 42;
            this.pictureBox.TabStop = false;
            // 
            // groupBox
            // 
            this.groupBox.Controls.Add(this.webBrowser);
            this.groupBox.Location = new System.Drawing.Point(428, 12);
            this.groupBox.Name = "groupBox";
            this.groupBox.Size = new System.Drawing.Size(735, 655);
            this.groupBox.TabIndex = 43;
            this.groupBox.TabStop = false;
            this.groupBox.Text = "https://en.wikipedia.org/wiki/Benjamin_Harrison";
            // 
            // webBrowser
            // 
            this.webBrowser.Dock = System.Windows.Forms.DockStyle.Fill;
            this.webBrowser.Location = new System.Drawing.Point(3, 16);
            this.webBrowser.MinimumSize = new System.Drawing.Size(20, 20);
            this.webBrowser.Name = "webBrowser";
            this.webBrowser.Size = new System.Drawing.Size(729, 636);
            this.webBrowser.TabIndex = 0;
            this.webBrowser.Url = new System.Uri("https://en.wikipedia.org/wiki/Benjamin_Harrison", System.UriKind.Absolute);
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(1076, 687);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(75, 23);
            this.exitButton.TabIndex = 44;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            // 
            // statusStrip
            // 
            this.statusStrip.Location = new System.Drawing.Point(0, 726);
            this.statusStrip.Name = "statusStrip";
            this.statusStrip.Size = new System.Drawing.Size(1163, 22);
            this.statusStrip.TabIndex = 45;
            this.statusStrip.Text = "statusStrip1";
            // 
            // progressBar
            // 
            this.progressBar.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(0)))), ((int)(((byte)(192)))), ((int)(((byte)(0)))));
            this.progressBar.Location = new System.Drawing.Point(0, 726);
            this.progressBar.Maximum = 120;
            this.progressBar.Name = "progressBar";
            this.progressBar.Size = new System.Drawing.Size(1073, 23);
            this.progressBar.TabIndex = 46;
            // 
            // errorProvider
            // 
            this.errorProvider.ContainerControl = this;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1163, 748);
            this.Controls.Add(this.progressBar);
            this.Controls.Add(this.statusStrip);
            this.Controls.Add(this.exitButton);
            this.Controls.Add(this.groupBox);
            this.Controls.Add(this.pictureBox);
            this.Controls.Add(this.filterGroupBox);
            this.Controls.Add(this.tJTextBox);
            this.Controls.Add(this.tRTextBox);
            this.Controls.Add(this.jATextBox);
            this.Controls.Add(this.gWTextBox);
            this.Controls.Add(this.mVTextBox);
            this.Controls.Add(this.dDETextBox);
            this.Controls.Add(this.rRTextBox);
            this.Controls.Add(this.wMTextBox);
            this.Controls.Add(this.tJRadioButton);
            this.Controls.Add(this.tRRadioButton);
            this.Controls.Add(this.jARadioButton);
            this.Controls.Add(this.gWRadioButton);
            this.Controls.Add(this.mVRadioButton);
            this.Controls.Add(this.dDERadioButton);
            this.Controls.Add(this.rRRadioButton);
            this.Controls.Add(this.wMRadioButton);
            this.Controls.Add(this.jFKTextBox);
            this.Controls.Add(this.bOTextBox);
            this.Controls.Add(this.gWBTextBox);
            this.Controls.Add(this.fPTextBox);
            this.Controls.Add(this.jBTextBox);
            this.Controls.Add(this.wJCTextBox);
            this.Controls.Add(this.fDRTextBox);
            this.Controls.Add(this.bHTextBox);
            this.Controls.Add(this.jFKRadioButton);
            this.Controls.Add(this.bORadioButton);
            this.Controls.Add(this.gWBRadioButton);
            this.Controls.Add(this.fPRadioButton);
            this.Controls.Add(this.jBRadioButton);
            this.Controls.Add(this.wJCRadioButton);
            this.Controls.Add(this.fDRRadioButton);
            this.Controls.Add(this.bHRadioButton);
            this.Name = "Form1";
            this.Text = "Presidents";
            this.filterGroupBox.ResumeLayout(false);
            this.filterGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox)).EndInit();
            this.groupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.RadioButton bHRadioButton;
        private System.Windows.Forms.RadioButton fDRRadioButton;
        private System.Windows.Forms.RadioButton wJCRadioButton;
        private System.Windows.Forms.RadioButton jBRadioButton;
        private System.Windows.Forms.RadioButton fPRadioButton;
        private System.Windows.Forms.RadioButton gWBRadioButton;
        private System.Windows.Forms.RadioButton bORadioButton;
        private System.Windows.Forms.RadioButton jFKRadioButton;
        private System.Windows.Forms.TextBox bHTextBox;
        private System.Windows.Forms.TextBox fDRTextBox;
        private System.Windows.Forms.TextBox wJCTextBox;
        private System.Windows.Forms.TextBox jBTextBox;
        private System.Windows.Forms.TextBox fPTextBox;
        private System.Windows.Forms.TextBox gWBTextBox;
        private System.Windows.Forms.TextBox bOTextBox;
        private System.Windows.Forms.TextBox jFKTextBox;
        private System.Windows.Forms.TextBox tJTextBox;
        private System.Windows.Forms.TextBox tRTextBox;
        private System.Windows.Forms.TextBox jATextBox;
        private System.Windows.Forms.TextBox gWTextBox;
        private System.Windows.Forms.TextBox mVTextBox;
        private System.Windows.Forms.TextBox dDETextBox;
        private System.Windows.Forms.TextBox rRTextBox;
        private System.Windows.Forms.TextBox wMTextBox;
        private System.Windows.Forms.RadioButton tJRadioButton;
        private System.Windows.Forms.RadioButton tRRadioButton;
        private System.Windows.Forms.RadioButton jARadioButton;
        private System.Windows.Forms.RadioButton gWRadioButton;
        private System.Windows.Forms.RadioButton mVRadioButton;
        private System.Windows.Forms.RadioButton dDERadioButton;
        private System.Windows.Forms.RadioButton rRRadioButton;
        private System.Windows.Forms.RadioButton wMRadioButton;
        private System.Windows.Forms.GroupBox filterGroupBox;
        private System.Windows.Forms.RadioButton fedRadioButton;
        private System.Windows.Forms.RadioButton dRRadioButton;
        private System.Windows.Forms.RadioButton repRadioButton;
        private System.Windows.Forms.RadioButton demRadioButton;
        private System.Windows.Forms.RadioButton allRadioButton;
        private System.Windows.Forms.PictureBox pictureBox;
        private System.Windows.Forms.GroupBox groupBox;
        private System.Windows.Forms.WebBrowser webBrowser;
        private System.Windows.Forms.Button exitButton;
        private System.Windows.Forms.StatusStrip statusStrip;
        private System.Windows.Forms.ProgressBar progressBar;
        private System.Windows.Forms.Timer timer;
        private System.Windows.Forms.ErrorProvider errorProvider;
        private System.Windows.Forms.ToolTip toolTip;
    }
}

